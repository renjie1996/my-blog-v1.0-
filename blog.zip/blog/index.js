var express = require('express');
var path = require('path');

// var indexRouter = require('./routes/index');
// var userRouter = require('./routes/users');
// var postRouter = require('./routes/posts');
// var signinRouter = require('./routes/signin');
// var signupRouter = require('./routes/signup');

var routes = require('./routes');

var app = express();



// app.get('/',function(req,res){
//     res.send('hello express');
// })

//设置模版位置,path.join
//当前目前路径
//__dirname当前路径 express/index.js
app.set('./views',path.join(__dirname, './views'));
//设置模版引擎?模版里有些变量，解析，高级的模版语法，快速输入html
app.set('view engine','ejs');
//静态资源都在public目录下，并且会提供 /css /js /img下补全
app.use(express.static(path.join(__dirname,'public')));

//中间件 express是一个依赖中间键处理web的框架，从用户请求到返回结束
//使用中间件来进行服务。
//在过程中，发生一件件的事情，
//mongoDB就是一个中间件，会一件一件的有顺序的
//例如：数据库连接、验证身份、登录、更新

// middleware 处理请求的，在它上面有一个next（）方法传给下一个中间件处理，
// 如果不调用，请求不传递

//res.render()渲染完html直接返回给客户端 app.use就是一个路由器中间件，没有next（）就终止对请求的处理。
//例如使用('/',indexRouter）若没有匹配成功，即执行下一条语句，反之用next（）继续传递

//app.use启用一个中间件
// app.use(function(req, res, next){
//   // console.log('1');
//   // next();
//   next(new Error('haha'));
// })

// app.use(function(req, res, next){
//   console.log('2');

//   //向结果对象输出清求：结束
//   res.status(200).end();
// })


//中间价处理错误
app.use(function(err,req,res,next){
  console.log(err.stack);
  // res.status(500).send('Something Broken');
  res.status(500).render('error');
})


routes(app);

//启用路由
// app.use('/',indexRouter);
// app.use('/users',userRouter);
// app.use('/posts',postRouter);
// app.use('/signin',signinRouter);
// app.use('/signup',signupRouter);

app.listen(3000,function(){
  console.log("listen in port:3000");
});