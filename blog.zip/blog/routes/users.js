var express = require('express');

var router = express.Router(); 

//动态的name /user/name :即是动态的占位符
router.get('/:name',function(req,res){
    //req请求对象 params 查询参数
    // res.send('hello ' + req.params.name);
    const supplies = ['mop','broom','duster'];
    res.render('users',{
        title:'用户模版',
        des:req.params.name,
        supplies: supplies,
        titleHtml: '<i>这是一个斜体的标题</i>'
    });
   
});

module.exports = router;
