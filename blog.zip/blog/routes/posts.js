var express = require('express');
// 产生一个路由
var router = express.Router();

//主页列表
router.get('/', function (req, res) {
  const posts = [{
    _id: '212323',
    created_at: '2017-03-25',
    commentsCount: 10,
    pv:2341,
      author: {
        name: 'XuRenJie',
        avatar: '/img/normal.0447fe9.png',
        bio: '哈哈哈哈我是你爸我比你大',
      },
        title:'敢问会Vue工资多少',
        content:'<i>杭州</i>，深圳，北京 10000+'
    }
  ]
  res.render('index',{
    posts:posts
  });
});


//发表文章
router.post('/create', function (req, res) {
});

//发表文章页
router.get('/create', function (req, res) {
});
//文章详情页
router.get('/:postId', function (req, res) {
});
//更新文章
router.get('/:postId/edit', function (req, res) {
});
//处理文章更新
router.post('/:postId/edit', function (req, res) {
});
//删除文章
router.get('/:postId/remove', function (req, res) {
});
//创建一条留言
router.post('/:postId/remove', function (req, res) {
});
//删除留言
router.get('/:postId/comment/:commentId/remove', function (req, res) {
});

module.exports = router;


