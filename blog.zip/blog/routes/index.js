// var express = require('express');

// //导游,产出路由方法实例
// var router = express.Router();

// //get是我们的访问方法,访问根路径
// router.get('/',function(req,res){
//     // res.send('hello ,express router');
//     //   /views/index.ejs

//     //显示一个模版，将数据传递过去，对象字面量
//     res.render('index',{
//         title: '铁头烧菜馆',
//         des: '小甲鱼特色菜'
//     })
// });


// module.exports = router;
module.exports = function(app) {
	app.get('/',function(req,res){
		//重定向
		res.redirect('/posts');
		app.use('/posts',require('./posts'));
		app.use('/signin',require('./signin'));
		app.use('/signup',require('./signup'));
		app.use('/users',require('./users'));

		//没有匹配到上述即404
		app.use(function(req,res){
			res.render('404');
		})

		// res.render('index',{});
	})
}

