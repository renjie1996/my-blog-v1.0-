var express = require('express');
// 产生一个路由
var router = express.Router();

//登录表单
router.get('/', function (req, res) {
  res.render('login',{});
});
router.post('/', function (req, res) {
  
});



module.exports = router;


